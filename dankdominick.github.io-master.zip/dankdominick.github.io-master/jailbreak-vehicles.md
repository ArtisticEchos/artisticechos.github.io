# Welcome to my Jailbreak vehicles page!
Here, I will list all the vehicles that I own in Jailbreak ROBLOX. This list will be updated as more vehicles are released, and as I buy more vehicles. If you do not know what Jailbreak is go to https://bit.ly/JailbreakROBLOX.

|Vehicle Name     |Vehicle Price           |Owned?     |Purchase Date|
|-----------------|------------------------|-----------|-------------|
|Helicopter       |Free                    |Yes        |N/A          |
|Camaro           |Free                    |Yes        |N/A          |
|Pickup Truck     |$9000                   |Yes        |N/A          |
|Model3           |$16,000                 |Yes        |2019-01-24   |
|Mini-Cooper      |$25,000                 |           |             |
|Dirtbike         |$35,000                 |Yes        |N/A          |
|SUV              |$40,000                 |           |             |
|Dune Buggy       |$45,000                 |           |             |
|Mustang          |$50,000                 |           |             |
|Classic Car      |$50,000                 |           |             |
|ATV              |$50,000                 |Yes        |2019-01-25   |
|Porsche          |$70,000                 |Yes        |2019-01-27   |
|Ambulance        |$90,000                 |           |             |
|Lamborghini      |$100,000                |Yes        |N/A          |
|Ferrari          |$200,000                |           |             |
|McLaren          |$300,000                |           |             |
|UFO              |$500,000                |           |             |
|Bugatti          |$500,000                |Yes        |N/A          |
|Torpedo          |$750,000                |Yes        |2019-02-09   |
|Arachnid         |$750,000                |           |             |
|Volt Bike        |$1,000,000              |           |             |
|Monster Truck    |$1,000,000              |           |             |
|BlackHawk        |$1,000,000              |Yes        |2019-01-24   |
|Wraith           |BOSS Gamepass (R$300)   |           |             |
|SWAT Van         |SWAT Gamepass (R$300)   |Yes        |N/A          |
