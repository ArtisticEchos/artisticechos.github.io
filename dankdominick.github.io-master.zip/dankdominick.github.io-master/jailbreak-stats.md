# Welcome to my Jailbreak stats page!
Here, I will list some stats in the game.

## I own:
- MVP
- [These cars](https://dankdominick.github.io/jailbreak-vehicles)

## Other stats:
- The most I have ever had in the game is 1,010,000
- 200+ Arrests (before season one)
- 1100+ Kills
- Level 30 criminal, level 1 police
